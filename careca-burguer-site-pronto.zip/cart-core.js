import { formatBRL, STORE_WHATSAPP } from './menu-core.js';

export const MAX_QUANTITY = 99;
export const MAX_NOTES_LENGTH = 1000;

function validId(value, label) {
  if (typeof value !== 'string' || !value.trim()) throw new Error(`${label} inválido`);
  return value;
}

function variantIdOrNull(value) {
  return value === undefined || value === null ? null : validId(value, 'Tamanho');
}

function validQuantity(quantity) {
  if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > MAX_QUANTITY) {
    throw new Error(`A quantidade deve ser um número inteiro entre 1 e ${MAX_QUANTITY}`);
  }
  return quantity;
}

function validPrice(price) {
  if (price === null) return null;
  if (!Number.isSafeInteger(price) || price < 0) throw new Error('Preço inválido no cardápio');
  return price;
}

function safeSum(a, b) {
  const result = a + b;
  if (!Number.isSafeInteger(result)) throw new Error('Total fora do limite permitido');
  return result;
}

function catalogById(items) {
  if (!Array.isArray(items)) throw new Error('Cardápio inválido');
  const catalog = new Map();
  for (const item of items) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) throw new Error('Item inválido no cardápio');
    const id = validId(item.id, 'Item');
    if (catalog.has(id)) throw new Error('Item duplicado no cardápio');
    catalog.set(id, item);
  }
  return catalog;
}

function canonicalSelection(catalog, itemId, variantId) {
  validId(itemId, 'Item');
  const item = catalog.get(itemId);
  if (!item) throw new Error('Item não encontrado no cardápio');
  if (typeof item.name !== 'string' || !item.name.trim()) throw new Error('Item sem nome válido');
  if (item.kind !== 'product' && item.kind !== 'addition') throw new Error('Tipo de item inválido');
  if (!Array.isArray(item.variants)) throw new Error('Tamanhos inválidos no cardápio');
  let variant = null;
  if (item.variants.length) {
    if (variantId === null) throw new Error('Selecione um tamanho válido');
    const seen = new Set();
    for (const option of item.variants) {
      if (!option || typeof option !== 'object' || Array.isArray(option)) throw new Error('Tamanho inválido no cardápio');
      validId(option.id, 'Tamanho');
      if (seen.has(option.id)) throw new Error('Tamanho duplicado no cardápio');
      seen.add(option.id);
      if (option.id === variantId) variant = option;
    }
    if (!variant) throw new Error('Selecione um tamanho válido');
    if (typeof variant.label !== 'string' || !variant.label.trim()) throw new Error('Tamanho sem nome válido');
  } else if (variantId !== null) {
    throw new Error('Este item não possui tamanhos');
  }
  return { item, variant, unitPriceCents: validPrice((variant ?? item).priceCents) };
}

export function cartKey(itemId, variantId = null) {
  return JSON.stringify([validId(itemId, 'Item'), variantIdOrNull(variantId)]);
}

/** Resolve only IDs and quantities supplied by the cart; every other field comes from the catalog. */
export function resolveCart(items, entries) {
  const catalog = catalogById(items);
  if (!Array.isArray(entries)) throw new Error('Carrinho inválido');
  const selections = new Map();
  for (const entry of entries) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) throw new Error('Entrada inválida no carrinho');
    const variantId = variantIdOrNull(entry.variantId);
    const { item, variant, unitPriceCents } = canonicalSelection(catalog, entry.itemId, variantId);
    const key = cartKey(item.id, variantId);
    const quantity = validQuantity((selections.get(key)?.quantity ?? 0) + validQuantity(entry.quantity));
    const lineTotalCents = unitPriceCents === null ? null : unitPriceCents * quantity;
    if (lineTotalCents !== null && !Number.isSafeInteger(lineTotalCents)) throw new Error('Total fora do limite permitido');
    selections.set(key, {
      key,
      itemId: item.id,
      variantId,
      quantity,
      name: item.name,
      kind: item.kind,
      variantLabel: variant?.label ?? null,
      unitPriceCents,
      lineTotalCents
    });
  }
  return [...selections.values()];
}

export function cartTotals(lines) {
  if (!Array.isArray(lines)) throw new Error('Carrinho inválido');
  return lines.reduce((total, line) => {
    if (!line || typeof line !== 'object' || Array.isArray(line)) throw new Error('Linha inválida no carrinho');
    validQuantity(line.quantity);
    validPrice(line.unitPriceCents);
    if (line.unitPriceCents === null) {
      if (line.lineTotalCents !== null) throw new Error('Subtotal inválido para item com valor a confirmar');
    } else if (!Number.isSafeInteger(line.lineTotalCents) || line.lineTotalCents !== line.unitPriceCents * line.quantity) {
      throw new Error('Subtotal inválido no carrinho');
    }
    return {
      quantity: safeSum(total.quantity, line.quantity),
      knownTotalCents: safeSum(total.knownTotalCents, line.lineTotalCents ?? 0),
      hasUnknownPrices: total.hasUnknownPrices || line.unitPriceCents === null
    };
  }, { quantity: 0, knownTotalCents: 0, hasUnknownPrices: false });
}

export function changeCartQuantity(items, entries, itemId, variantId = null, delta = 1) {
  if (!Number.isSafeInteger(delta) || delta === 0) throw new Error('Alteração de quantidade inválida');
  const canonicalVariantId = variantIdOrNull(variantId);
  canonicalSelection(catalogById(items), itemId, canonicalVariantId);
  const key = cartKey(itemId, canonicalVariantId);
  const lines = resolveCart(items, entries);
  const selected = lines.find(line => line.key === key);
  const quantity = (selected?.quantity ?? 0) + delta;
  if (!Number.isSafeInteger(quantity) || quantity < 0 || quantity > MAX_QUANTITY) {
    throw new Error(`A quantidade deve ficar entre 0 e ${MAX_QUANTITY}`);
  }
  const next = lines.filter(line => line.key !== key).map(line => ({
    itemId: line.itemId, variantId: line.variantId, quantity: line.quantity
  }));
  if (quantity > 0) {
    const replacement = { itemId, variantId: canonicalVariantId, quantity };
    if (selected) next.splice(lines.indexOf(selected), 0, replacement);
    else next.push(replacement);
  }
  return next;
}

export function buildCartWhatsAppUrl(items, entries, notes = '') {
  const lines = resolveCart(items, entries);
  if (!lines.length) throw new Error('Adicione pelo menos um item ao carrinho');
  if (typeof notes !== 'string') throw new Error('Observações inválidas');
  const cleanedNotes = notes.replace(/\r\n?/g, '\n').trim()
    .replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDFFF]/g, value => value.length === 2 ? value : '\uFFFD');
  if (cleanedNotes.length > MAX_NOTES_LENGTH || cleanedNotes.includes('\0')) {
    throw new Error(`As observações devem ter até ${MAX_NOTES_LENGTH} caracteres`);
  }
  const totals = cartTotals(lines);
  const message = ['Olá, Careca Burguer Buritis! Eu vim pelo site e gostaria de fazer este pedido:', ''];
  for (const [index, line] of lines.entries()) {
    const name = line.kind === 'addition' ? `Acréscimo: ${line.name.replace(/^Acréscimo de /i, '')}` : line.name;
    message.push(`${index + 1}. ${line.quantity} × ${name}`);
    if (line.variantLabel) message.push(`Tamanho: ${line.variantLabel}`);
    message.push(line.unitPriceCents === null
      ? 'Preço unitário e subtotal: a confirmar'
      : `Preço unitário: ${formatBRL(line.unitPriceCents)} | Subtotal: ${formatBRL(line.lineTotalCents)}`);
    message.push('');
  }
  message.push(`Quantidade total: ${totals.quantity}`);
  if (totals.hasUnknownPrices) {
    if (lines.some(line => line.unitPriceCents !== null)) {
      message.push(`Subtotal dos itens com preço informado: ${formatBRL(totals.knownTotalCents)}`);
    }
    message.push('Há itens com valor a confirmar. O total do pedido depende desses valores.');
  } else {
    message.push(`Total dos itens no cardápio: ${formatBRL(totals.knownTotalCents)}`);
  }
  message.push('Taxa de entrega e gorjeta não incluídas.');
  if (cleanedNotes) message.push('', `Observações: ${cleanedNotes}`);
  message.push('', 'Pode confirmar os valores, a disponibilidade e as opções de entrega ou retirada?');
  return `https://wa.me/${STORE_WHATSAPP}?text=${encodeURIComponent(message.join('\n'))}`;
}
