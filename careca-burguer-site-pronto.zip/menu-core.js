export const STORE_WHATSAPP = '5531971697602';
export const generalWhatsAppUrl = `https://wa.me/${STORE_WHATSAPP}?text=${encodeURIComponent('Olá, Careca Burguer Buritis! Eu vim pelo site e gostaria de fazer um pedido.')}`;

export function formatBRL(cents) {
  if (!Number.isInteger(cents) || cents < 0) throw new Error('Preço inválido no cardápio');
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(cents / 100);
}

export function buildWhatsAppUrl(item, variant = null) {
  if (!item || typeof item.name !== 'string' || !item.name.trim()) throw new Error('Item sem nome válido');
  if (item.variants?.length) {
    if (!variant || !item.variants.some(v => v.id === variant.id)) throw new Error('Selecione uma variante válida');
    variant = item.variants.find(v => v.id === variant.id);
  } else if (variant !== null) throw new Error('Este item não possui variantes');
  const selected = variant ?? item;
  const priced = selected.priceCents !== null && selected.priceCents !== undefined;
  if (priced) formatBRL(selected.priceCents);
  const label = item.kind === 'addition' ? 'Acréscimo' : 'Item';
  const name = item.kind === 'addition' ? item.name.replace(/^Acréscimo de /i, '') : item.name;
  const lines = [priced ? 'Olá, Careca Burguer Buritis! Eu vim pelo site e gostaria de pedir:' : 'Olá, Careca Burguer Buritis! Eu vim pelo site e gostaria de consultar:', '', `${label}: ${name}`];
  if (variant) lines.push(`Tamanho: ${variant.label}`);
  if (priced) lines.push('Quantidade: 1', `Preço do item no cardápio: ${formatBRL(selected.priceCents)}`);
  lines.push('', priced ? 'Pode confirmar a disponibilidade e me orientar sobre a entrega?' : 'Pode informar as opções, o valor e a disponibilidade para incluir no meu pedido?');
  return `https://wa.me/${STORE_WHATSAPP}?text=${encodeURIComponent(lines.join('\n'))}`;
}

export function normalizeSearch(value) {
  return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR').replace(/\s+/g, ' ').trim();
}

export function findItems(items, query) {
  const terms = normalizeSearch(query).split(' ').filter(Boolean);
  return items.filter(item => {
    const text = normalizeSearch(`${item.name} ${item.description || ''}`);
    return terms.every(term => text.includes(term));
  });
}

export function escapeHtml(text = '') {
  return String(text).replace(/[&<>"']/g, char => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[char]));
}

export const iconPaths = {
  arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
  diagonal: '<path d="M6 18 18 6M6 6h12v12"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/>',
  close: '<path d="m6 6 12 12M6 18 18 6"/>',
  pin: '<path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.01"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  up: '<path d="M12 19V5m-6 6 6-6 6 6"/>',
  whatsapp: '<path d="M21 11.5a9 9 0 0 1-13.8 7.7L3 21l1.6-5.1A9 9 0 1 1 21 11.5Z"/><path d="M8 7c-1 2 1 6 5 8 2 1 3 0 3-1l-3-2-1 1c-1-1-2-2-3-3l1-1-2-2Z"/>',
  phone: '<path d="m8 3 3 5-2 2c1.4 2.8 2.9 4.3 5 5l2-2 5 3c-1 5-4 6-9 3S4 13 3 8 5 3 8 3Z"/>',
  cart: '<path d="M3 3h2l3 12h10l3-9H6"/><circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/>',
  plus: '<path d="M12 5v14M5 12h14"/>'
};
export function icon(name, className = '') {
  return `<svg class="icon ${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name] || iconPaths.arrow}</svg>`;
}

export function renderItem(item) {
  const e = escapeHtml;
  const addition = item.kind === 'addition';
  const accessibleName = addition ? item.name.replace(/^Acréscimo de /i, '') : item.name;
  const tag = addition ? '<span class="item-tag">Acréscimo opcional</span>' : '';
  const top = `<div class="item-top"><span class="item-number">${item.sourceNumber ? String(item.sourceNumber).padStart(2, '0') : ''}</span>${tag}</div>`;
  const desc = item.description ? `<p class="item-description">${e(item.description)}</p>` : '';
  const content = `${top}<h4>${e(item.name)}</h4>${desc}`;
  if (item.variants?.length) {
    return `<article class="menu-card has-variants" data-item-id="${e(item.id)}">${content}<div class="variant-links">${item.variants.map(v => `<button type="button" class="variant-link" data-add-item="${e(item.id)}" data-variant-id="${e(v.id)}" aria-label="Adicionar ${e(item.name)} ${e(v.label)} por ${e(formatBRL(v.priceCents))} ao carrinho"><span>${e(v.label)}</span><strong>${e(formatBRL(v.priceCents))}</strong>${icon('plus')}</button>`).join('')}</div></article>`;
  }
  const price = item.priceCents === null ? 'Consultar valor' : formatBRL(item.priceCents);
  return `<article class="menu-card" data-item-id="${e(item.id)}">${content}<div class="item-bottom"><strong class="price ${item.priceCents === null ? 'price-consult' : ''}">${e(price)}</strong><button type="button" class="item-action" data-add-item="${e(item.id)}" aria-label="Adicionar ${addition ? 'acréscimo de ' : ''}${e(accessibleName)} ao carrinho">Adicionar ${icon('plus')}</button></div></article>`;
}

export function renderGroups(items, categories) {
  return categories.map(category => {
    const group = items.filter(item => item.category === category.id);
    if (!group.length) return '';
    return `<section class="menu-group" id="categoria-${escapeHtml(category.id)}" data-category="${escapeHtml(category.id)}" aria-label="${escapeHtml(category.label)}"><div class="menu-group-heading"><h3>${escapeHtml(category.label)}</h3><span>${group.length} ${group.length === 1 ? 'opção' : 'opções'}</span></div><div class="menu-grid">${group.map(renderItem).join('')}</div></section>`;
  }).join('');
}
