import { findItems, normalizeSearch, renderGroups, formatBRL, escapeHtml, icon } from './menu-core.js';
import { MAX_QUANTITY, resolveCart, cartTotals, changeCartQuantity, buildCartWhatsAppUrl } from './cart-core.js';

const catalog = JSON.parse(document.querySelector('#catalog-data').textContent);
const search = document.querySelector('#menu-search');
const clear = document.querySelector('#clear-search');
const results = document.querySelector('#menu-results');
const summary = document.querySelector('#results-summary');
const tabs = [...document.querySelectorAll('.category-tab')];
const categoryIndicator = document.querySelector('.category-indicator');
const motion = matchMedia('(prefers-reduced-motion: reduce)');
const finePointer = matchMedia('(hover: hover) and (pointer: fine)');
const hero = document.querySelector('.hero');
const heroVisual = document.querySelector('.hero-visual');
const scrollProgress = document.querySelector('.scroll-progress');
const photoMotion = [...document.querySelectorAll('.photo-motion img')].map(image => ({ image, frame: image.closest('.photo-motion') }));
const flavorTracks = [...document.querySelectorAll('.flavor-track')];
const visibleFlavorTracks = new Set();
const motionToggle = document.querySelector('.motion-toggle');
let flavorPaused = false;
let flavorKeyboardConsent = false;
const dialogControllers = new Set();
const revealAnimations = new Set();
let currentCategory = 'lanches';

function finishHeroEntrance() { hero?.classList.add('hero-entrance-done'); }
heroVisual?.addEventListener('animationend', event => {
  if (event.target === heroVisual && event.animationName === 'food-arrive') finishHeroEntrance();
});
if (motion.matches) finishHeroEntrance();

function canAnimate(event) {
  return !motion.matches && !document.documentElement.classList.contains('keyboard-input')
    && !(event?.type === 'click' && event.detail === 0) && !navigator.connection?.saveData;
}

function syncFlavorMotion() {
  const saveData = Boolean(navigator.connection?.saveData);
  document.documentElement.classList.toggle('save-data', saveData);
  const keyboardPaused = document.documentElement.classList.contains('keyboard-input') && !flavorKeyboardConsent;
  flavorTracks.forEach(track => track.classList.toggle('is-paused', flavorPaused || document.hidden || !visibleFlavorTracks.has(track) || motion.matches || saveData || keyboardPaused));
  motionToggle?.closest('.flavor-ribbon')?.classList.toggle('motion-paused', flavorPaused);
}

motionToggle?.addEventListener('click', () => {
  flavorPaused = !flavorPaused;
  // An explicit play request takes precedence over the general keyboard pause.
  // Visibility, reduced motion and data saving still take precedence over play.
  flavorKeyboardConsent = !flavorPaused;
  motionToggle.setAttribute('aria-pressed', String(flavorPaused));
  motionToggle.setAttribute('aria-label', flavorPaused ? 'Retomar animação da faixa' : 'Pausar animação da faixa');
  syncFlavorMotion();
});

// Input mode also gates CSS press/hover transitions and smooth scrolling.
document.addEventListener('keydown', event => {
  if (event.isComposing) return;
  finishHeroEntrance();
  document.documentElement.classList.add('keyboard-input');
  dialogControllers.forEach(controller => controller.settle());
  revealAnimations.forEach(animation => animation.cancel());
  revealAnimations.clear();
  syncFlavorMotion();
  onScroll();
}, { capture: true });
document.addEventListener('pointerdown', () => {
  document.documentElement.classList.remove('keyboard-input');
  syncFlavorMotion();
  onScroll();
}, { capture: true, passive: true });

function updateCategoryIndicator() {
  if (!categoryIndicator) return;
  const active = tabs.find(tab => tab.getAttribute('aria-pressed') === 'true');
  categoryIndicator.hidden = !active;
  if (active) categoryIndicator.style.transform = `translateX(${active.offsetLeft}px) scaleX(${active.offsetWidth})`;
}

function updateMenu() {
  const query = normalizeSearch(search.value);
  const matches = query ? findItems(catalog.items, query) : catalog.items.filter(i => i.category === currentCategory);
  tabs.forEach(tab => tab.setAttribute('aria-pressed', String(!query && tab.dataset.category === currentCategory)));
  updateCategoryIndicator();
  clear.hidden = !search.value;
  if (matches.length) {
    results.innerHTML = renderGroups(matches, catalog.categories);
    summary.textContent = query ? `${matches.length} ${matches.length === 1 ? 'resultado encontrado' : 'resultados encontrados'} em todo o cardápio.` : `${matches.length} opções. Adicione ao carrinho.`;
  } else {
    results.innerHTML = `<div class="empty-state"><h3>Não encontramos esse item.</h3><p>Tente outro nome ou ingrediente.</p><button class="button button-outline" type="button" data-reset-search>Limpar busca</button></div>`;
    summary.textContent = 'Nenhum resultado encontrado.';
  }
}

function chooseCategory(category, scroll = false) {
  if (!catalog.categories.some(c => c.id === category)) return;
  currentCategory = category;
  search.value = '';
  updateMenu();
  if (scroll) document.querySelector('#cardapio').scrollIntoView({ block: 'start', behavior: canAnimate() ? 'smooth' : 'auto' });
}

search.addEventListener('input', updateMenu);
clear.addEventListener('click', () => { search.value = ''; updateMenu(); search.focus(); });
tabs.forEach(tab => tab.addEventListener('click', () => chooseCategory(tab.dataset.category)));
results.addEventListener('click', event => {
  if (event.target.closest('[data-reset-search]')) { search.value = ''; updateMenu(); search.focus(); }
});
document.querySelectorAll('[data-select-category]').forEach(link => link.addEventListener('click', event => {
  event.preventDefault();
  chooseCategory(link.dataset.selectCategory, true);
}));
updateMenu();
let indicatorFrame = 0;
addEventListener('resize', () => {
  if (indicatorFrame) return;
  indicatorFrame = requestAnimationFrame(() => { updateCategoryIndicator(); indicatorFrame = 0; });
}, { passive: true });
document.fonts?.ready.then(updateCategoryIndicator);

const menuToggle = document.querySelector('.menu-toggle');
const mobileNav = document.querySelector('.mobile-nav');
function closeNav(restoreFocus = false) {
  mobileNav.hidden = true;
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'Abrir navegação');
  if (restoreFocus) menuToggle.focus({ preventScroll: true });
}
menuToggle.addEventListener('click', () => {
  const open = menuToggle.getAttribute('aria-expanded') !== 'true';
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Fechar navegação' : 'Abrir navegação');
  mobileNav.hidden = !open;
});
mobileNav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => closeNav()));
document.addEventListener('pointerdown', event => {
  if (!mobileNav.hidden && !event.target.closest('.mobile-nav, .menu-toggle')) closeNav();
}, { passive: true });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && !mobileNav.hidden) closeNav(mobileNav.contains(document.activeElement));
});

function syncDialogLock() {
  document.body.classList.toggle('dialog-open', Boolean(document.querySelector('dialog[open]')));
}

// Keep the native dialog's top layer, focus trap, cancel event and focus restoration.
// When reversed, sample the current frame before canceling instead of restarting.
function createDialogController(element, closedTransform) {
  let animation = null;
  let phase = 'closed';
  let revision = 0;
  let afterClose = null;
  const cancelAnimation = () => {
    revision += 1;
    animation?.cancel();
    animation = null;
  };
  const completeClose = () => {
    cancelAnimation();
    phase = 'closed';
    const callback = afterClose;
    afterClose = null;
    if (element.open) element.close();
    syncDialogLock();
    callback?.();
  };
  const animateTo = (from, to, duration, done) => {
    const token = revision;
    animation = element.animate([from, to], {
      duration, easing: 'cubic-bezier(.32,.72,0,1)', fill: 'both'
    });
    animation.finished.then(() => {
      if (token !== revision) return;
      done();
    }).catch(() => { /* A newer action owns this dialog now. */ });
  };
  const controller = {
    open(event) {
      if (element.open && phase === 'open') return;
      const wasOpen = element.open;
      const style = wasOpen ? getComputedStyle(element) : null;
      const from = wasOpen ? { opacity: style.opacity, transform: style.transform }
        : { opacity: 0, transform: closedTransform };
      cancelAnimation();
      afterClose = null;
      if (!wasOpen) element.showModal();
      phase = 'open';
      syncDialogLock();
      if (!canAnimate(event) || typeof element.animate !== 'function') return;
      animateTo(from, { opacity: 1, transform: 'none' }, 260, cancelAnimation);
    },
    close(event, callback = null, immediate = false) {
      if (!element.open) { callback?.(); return; }
      afterClose = callback;
      if (immediate || !canAnimate(event) || typeof element.animate !== 'function') { completeClose(); return; }
      if (phase === 'closing') return;
      const style = getComputedStyle(element);
      const from = { opacity: style.opacity, transform: style.transform };
      cancelAnimation();
      phase = 'closing';
      animateTo(from, { opacity: 0, transform: closedTransform }, 180, completeClose);
    },
    settle() {
      if (phase === 'closing') completeClose();
      else cancelAnimation();
    }
  };
  element.addEventListener('cancel', event => {
    event.preventDefault();
    controller.close(event, null, true);
  });
  element.addEventListener('close', () => {
    // A queued close event can arrive after a rapid reopen; preserve that new cycle.
    if (element.open) return;
    cancelAnimation();
    phase = 'closed';
    afterClose = null;
    syncDialogLock();
  });
  dialogControllers.add(controller);
  return controller;
}

const dialog = document.querySelector('#store-dialog');
const storeController = createDialogController(dialog, 'translateY(8px) scale(.97)');
document.querySelectorAll('[data-store-info]').forEach(link => link.addEventListener('click', event => {
  if (typeof dialog.showModal !== 'function') return;
  event.preventDefault();
  closeNav();
  storeController.open(event);
}));
dialog.querySelector('.dialog-close').addEventListener('click', event => storeController.close(event));
dialog.addEventListener('click', event => {
  const box = dialog.getBoundingClientRect();
  if (event.target === dialog && (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom)) storeController.close(event);
});

const header = document.querySelector('.site-header');
let frame = 0;
function onScroll() {
  if (frame) return;
  frame = requestAnimationFrame(() => {
    header.classList.toggle('header-scrolled', scrollY > 20);
    const pageLength = document.documentElement.scrollHeight - innerHeight;
    if (scrollProgress) scrollProgress.style.transform = `scaleX(${pageLength > 0 ? Math.min(1, Math.max(0, scrollY / pageLength)) : 0})`;
    // Read each stationary wrapper before writing image transforms. The card's
    // own rotation and the hero's entrance remain independent of the scrub.
    const photoFrames = canAnimate() && finePointer.matches && !document.hidden
      ? photoMotion.map(photo => ({ ...photo, box: photo.frame.getBoundingClientRect() })) : [];
    if (photoFrames.length) {
      photoFrames.forEach(({ image, box }) => {
        if (box.bottom < 0 || box.top > innerHeight) return;
        const limit = Math.min(12, box.height * .025);
        const travel = Math.max(-limit, Math.min(limit, ((innerHeight / 2 - box.top - box.height / 2) / (innerHeight + box.height)) * 48));
        image.style.transform = `translateY(${travel.toFixed(2)}px) scale(1.06)`;
      });
    } else {
      photoMotion.forEach(({ image }) => image.style.removeProperty('transform'));
    }
    frame = 0;
  });
}
addEventListener('scroll', onScroll, { passive: true });
addEventListener('resize', onScroll, { passive: true });
document.addEventListener('visibilitychange', () => { syncFlavorMotion(); onScroll(); });
finePointer.addEventListener('change', onScroll);
navigator.connection?.addEventListener?.('change', () => { syncFlavorMotion(); onScroll(); });
motion.addEventListener('change', () => {
  if (motion.matches) {
    finishHeroEntrance();
    dialogControllers.forEach(controller => controller.settle());
    revealAnimations.forEach(animation => animation.cancel());
    revealAnimations.clear();
  }
  syncFlavorMotion();
  onScroll();
});
onScroll();

if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.filter(entry => entry.isIntersecting).forEach((entry, index) => {
      observer.unobserve(entry.target);
      entry.target.dataset.motionRevealed = 'true';
      if (!canAnimate() || typeof entry.target.animate !== 'function') return;
      const requestedDelay = Number(entry.target.dataset.motionDelay);
      const delay = Number.isFinite(requestedDelay) ? Math.max(0, Math.min(180, requestedDelay)) : Math.min(index * 60, 180);
      const animation = entry.target.animate([
        { opacity: 0, transform: 'translateY(16px)' },
        { opacity: 1, transform: 'none' }
      ], { duration: 600, delay, easing: 'cubic-bezier(.23,1,.32,1)', fill: 'both' });
      revealAnimations.add(animation);
      animation.finished.then(() => { animation.cancel(); }).catch(() => {})
        .finally(() => revealAnimations.delete(animation));
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.motion-reveal').forEach(target => observer.observe(target));
  const flavorObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) visibleFlavorTracks.add(entry.target);
      else visibleFlavorTracks.delete(entry.target);
    });
    syncFlavorMotion();
  });
  flavorTracks.forEach(track => flavorObserver.observe(track));
} else {
  flavorTracks.forEach(track => visibleFlavorTracks.add(track));
}
syncFlavorMotion();

// Keep only selections and quantities; displayed prices always come from the catalog.
const cartStorageKey = 'careca-buritis-cart-v1';
const cartDialog = document.querySelector('#cart-dialog');
const cartController = createDialogController(cartDialog, 'translateX(24px)');
const cartItems = document.querySelector('#cart-items');
const cartCheckout = document.querySelector('#cart-checkout');
const cartNotes = document.querySelector('#cart-notes');
const cartSend = document.querySelector('#cart-send');
const cartStatus = document.querySelector('#cart-status');
let cartEntries = [];
let toastTimer;
const feedbackTimers = new WeakMap();
function confirmAddition(button, event) {
  if (!canAnimate(event)) return;
  const targets = [{ element: button, className: 'is-added', hold: 550 }, ...[...document.querySelectorAll('[data-cart-count]')].map(element => ({ element, className: 'is-updating', hold: 160 }))];
  targets.forEach(({ element, className, hold }) => {
    clearTimeout(feedbackTimers.get(element));
    element.classList.add(className);
    feedbackTimers.set(element, setTimeout(() => {
      element.classList.remove(className);
      feedbackTimers.delete(element);
    }, hold));
  });
}
function cleanCartNotes(value) {
  let cleaned = '';
  for (const character of String(value).replace(/\0/g, '')) {
    const code = character.charCodeAt(0);
    if (character.length === 1 && code >= 0xd800 && code <= 0xdfff) continue;
    if (cleaned.length + character.length > 500) break;
    cleaned += character;
  }
  return cleaned;
}
try {
  const saved = JSON.parse(localStorage.getItem(cartStorageKey));
  if (saved && Array.isArray(saved.entries)) {
    cartEntries = resolveCart(catalog.items, saved.entries).map(line => ({ itemId: line.itemId, variantId: line.variantId, quantity: line.quantity }));
    cartNotes.value = typeof saved.notes === 'string' ? cleanCartNotes(saved.notes) : '';
  }
} catch { /* The cart also works when browser storage is unavailable or invalid. */ }

function saveCart() {
  if (!cartEntries.length) cartNotes.value = '';
  try { localStorage.setItem(cartStorageKey, JSON.stringify({ entries: cartEntries, notes: cartNotes.value })); } catch { /* Browser-local persistence is optional. */ }
}
function announceCart(message) {
  clearTimeout(toastTimer);
  cartStatus.textContent = message;
  if (cartDialog.open) document.querySelector('#cart-dialog-status').textContent = message;
  cartStatus.classList.add('is-visible');
  toastTimer = setTimeout(() => cartStatus.classList.remove('is-visible'), 3000);
}
function updateCartLink() {
  if (cartEntries.length) cartSend.href = buildCartWhatsAppUrl(catalog.items, cartEntries, cartNotes.value);
  else cartSend.removeAttribute('href');
}
function renderCart() {
  const lines = resolveCart(catalog.items, cartEntries);
  const total = cartTotals(lines);
  document.querySelectorAll('[data-cart-count]').forEach(count => { count.textContent = String(total.quantity); });
  document.querySelectorAll('[data-cart-total]').forEach(node => {
    node.textContent = total.hasUnknownPrices ? (total.knownTotalCents ? `Parcial ${formatBRL(total.knownTotalCents)}` : 'A consultar') : formatBRL(total.knownTotalCents);
  });
  cartCheckout.hidden = !lines.length;
  if (!lines.length) cartNotes.value = '';
  document.querySelector('#cart-total-label').textContent = total.hasUnknownPrices ? 'Subtotal dos itens com preço' : 'Subtotal dos itens';
  document.querySelector('#cart-total').textContent = total.hasUnknownPrices && !total.knownTotalCents ? 'A confirmar' : formatBRL(total.knownTotalCents);
  const notice = document.querySelector('#cart-price-notice');
  notice.textContent = total.hasUnknownPrices ? 'Há itens com valor a confirmar. Eles serão consultados na mesma mensagem e não estão incluídos no subtotal.' : '';
  notice.hidden = !total.hasUnknownPrices;
  cartItems.innerHTML = lines.length ? lines.map(line => {
    const name = line.kind === 'addition' ? `Acréscimo: ${line.name.replace(/^Acréscimo de /i, '')}` : line.name;
    const label = `${name}${line.variantLabel ? ` (${line.variantLabel})` : ''}`;
    const unit = line.unitPriceCents === null ? 'Valor a confirmar' : `${formatBRL(line.unitPriceCents)} por unidade`;
    return `<article class="cart-item" data-cart-key="${escapeHtml(line.key)}"><div class="cart-item-top"><div><h3>${escapeHtml(name)}</h3>${line.variantLabel ? `<p class="cart-variant">${escapeHtml(line.variantLabel)}</p>` : ''}<p class="cart-unit">${escapeHtml(unit)}</p></div><button type="button" class="cart-remove" data-cart-action="remove" aria-label="Remover ${escapeHtml(label)}">${icon('close')}</button></div><div class="cart-item-bottom"><div class="cart-quantity" role="group" aria-label="Quantidade de ${escapeHtml(label)}"><button type="button" data-cart-action="decrease" aria-label="Diminuir quantidade de ${escapeHtml(label)}">−</button><span>${line.quantity}</span><button type="button" data-cart-action="increase" aria-label="Aumentar quantidade de ${escapeHtml(label)}" ${line.quantity >= MAX_QUANTITY ? 'disabled' : ''}>+</button></div><strong class="cart-line-total">${line.lineTotalCents === null ? 'A confirmar' : escapeHtml(formatBRL(line.lineTotalCents))}</strong></div></article>`;
  }).join('') : `<div class="cart-empty">${icon('cart')}<h3>Seu carrinho está vazio.</h3><p>Adicione seus favoritos para montar o pedido.</p><button type="button" class="button button-wine" data-close-cart data-go-menu>Escolher no cardápio ${icon('arrow')}</button></div>`;
  updateCartLink();
}
function closeCart(event, callback = null) { cartController.close(event, callback); }
document.querySelectorAll('[data-open-cart]').forEach(button => button.addEventListener('click', event => {
  if (!cartDialog.open) renderCart();
  closeNav();
  cartController.open(event);
}));
cartDialog.addEventListener('click', event => {
  if (event.target.closest('.cart-close, [data-close-cart]')) {
    closeCart(event, event.target.closest('[data-go-menu]') ? () => chooseCategory(currentCategory, true) : null);
    return;
  }
  const box = cartDialog.getBoundingClientRect();
  if (event.target === cartDialog && (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom)) closeCart(event);
});
document.addEventListener('click', event => {
  const add = event.target.closest('[data-add-item]');
  if (!add) return;
  try {
    cartEntries = changeCartQuantity(catalog.items, cartEntries, add.dataset.addItem, add.dataset.variantId || null, 1);
    saveCart();
    renderCart();
    confirmAddition(add, event);
    const item = catalog.items.find(item => item.id === add.dataset.addItem);
    const variant = item.variants.find(variant => variant.id === add.dataset.variantId);
    const selection = resolveCart(catalog.items, cartEntries).find(line => line.itemId === item.id && line.variantId === (variant?.id || null));
    announceCart(`${item.name}${variant ? ` (${variant.label})` : ''} adicionado ao carrinho. Quantidade: ${selection.quantity}.`);
  } catch { announceCart(`Limite de ${MAX_QUANTITY} unidades por item. Ajuste a quantidade no carrinho.`); }
});
cartItems.addEventListener('click', event => {
  const action = event.target.closest('[data-cart-action]');
  if (!action) return;
  const key = action.closest('[data-cart-key]').dataset.cartKey;
  const line = resolveCart(catalog.items, cartEntries).find(line => line.key === key);
  if (!line) return;
  const remove = action.dataset.cartAction === 'remove';
  try {
    cartEntries = changeCartQuantity(catalog.items, cartEntries, line.itemId, line.variantId, remove ? -line.quantity : action.dataset.cartAction === 'increase' ? 1 : -1);
    saveCart();
    renderCart();
    const updatedRow = [...cartItems.querySelectorAll('[data-cart-key]')].find(row => row.dataset.cartKey === key);
    const next = updatedRow?.querySelector(`[data-cart-action="${action.dataset.cartAction}"]:not(:disabled)`) || updatedRow?.querySelector('[data-cart-action="decrease"]') || cartItems.querySelector('button') || cartDialog.querySelector('.cart-close');
    next.focus();
    announceCart(remove || (action.dataset.cartAction === 'decrease' && line.quantity === 1) ? `${line.name} removido do carrinho.` : `${line.name}${line.variantLabel ? ` (${line.variantLabel})` : ''}: quantidade ${line.quantity + (action.dataset.cartAction === 'increase' ? 1 : -1)}.`);
  } catch { announceCart(`A quantidade máxima por item é ${MAX_QUANTITY}.`); }
});
cartNotes.addEventListener('input', () => { cartNotes.value = cleanCartNotes(cartNotes.value); updateCartLink(); saveCart(); });
cartSend.addEventListener('click', event => {
  if (!cartEntries.length) { event.preventDefault(); return; }
  updateCartLink();
});
renderCart();
